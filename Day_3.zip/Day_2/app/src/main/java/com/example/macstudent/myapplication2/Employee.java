package com.example.macstudent.myapplication2;


import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by macstudent on 2018-04-06.
 */


public class Employee implements Parcelable {

    private int empId;
    private String empName;
    private double salary;
    private boolean gender; // True = male , False = female

    protected Employee(Parcel in) {
        empId = in.readInt();
        empName = in.readString();
        salary = in.readDouble();
        gender = in.readByte() != 0;
    }

    public static final Creator<Employee> CREATOR = new Creator<Employee>() {
        @Override
        public Employee createFromParcel(Parcel in) {
            return new Employee(in);
        }

        @Override
        public Employee[] newArray(int size) {
            return new Employee[size];
        }
    };

    public Employee() {

    }

    public int getEmpId() {
        return empId;
    }

    public void setEmpId(int empId) {
        this.empId = empId;
    }

    public String getEmpName() {
        return empName;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public boolean isGender() {
        return gender;
    }

    public void setGender(boolean gender) {
        this.gender = gender;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "empId=" + empId +
                ", empName='" + empName + '\'' +
                ", gender=" + gender +
                '}';
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {


        parcel.writeInt(empId);
        parcel.writeString(empName);
        parcel.writeDouble(salary);
        parcel.writeByte((byte) (gender ? 1 : 0));
    }
}
