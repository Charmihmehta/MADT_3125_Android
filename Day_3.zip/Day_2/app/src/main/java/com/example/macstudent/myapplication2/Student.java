package com.example.macstudent.myapplication2;

import java.io.Serializable;

/**
 * Created by macstudent on 2018-04-06.
 */

public class Student implements Serializable {
    private int studentId;
    private String studentName;

    public int getStudentId() {
        return studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;

    }

    @Override
    public String toString() {
        return "Student{" +
                "studentId=" + studentId +
                ", studentName='" + studentName + '\'' +
                '}';
    }
}
