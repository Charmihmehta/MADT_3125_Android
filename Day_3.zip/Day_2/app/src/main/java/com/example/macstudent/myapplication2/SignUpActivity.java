package com.example.macstudent.myapplication2;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class SignUpActivity extends Activity {
    private static final String TAG = SignUpActivity.class.getName();

    EditText userName;
    EditText email;
    EditText psw;
    EditText rePsw;
    RadioGroup gender;
    Button register;
    RadioButton male;
    RadioButton female;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);


        String name = getIntent().getStringExtra("name");
        int age = getIntent().getIntExtra("age", 0);
        Toast.makeText(SignUpActivity.this, name + age, Toast.LENGTH_LONG).show();

        Student student = (Student) getIntent().getSerializableExtra("Student");
        Log.d(TAG, student.toString());

        Employee employee = (Employee) getIntent().getParcelableExtra("Employee");
        Log.d(TAG, employee.toString());

        userName = (EditText) findViewById(R.id.name);
        email = (EditText) findViewById(R.id.email);
        psw = (EditText) findViewById(R.id.psw);
        rePsw = (EditText) findViewById(R.id.repsw);
        gender = (RadioGroup) findViewById(R.id.gender);
        male = (RadioButton) findViewById(R.id.male);
        female = (RadioButton) findViewById(R.id.female);


        gender.check(R.id.female);


        register = (Button) findViewById(R.id.register);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(SignUpActivity.this, "Hello New user !!! ", Toast.LENGTH_LONG).show();

            }
        });

    }

    @Override
    public void onBackPressed() {


    }
}
