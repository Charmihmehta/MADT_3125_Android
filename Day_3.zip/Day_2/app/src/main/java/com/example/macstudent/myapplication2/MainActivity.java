package com.example.macstudent.myapplication2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {

    EditText editId;
    EditText editpsw;

    Button btnSignin;
    Button btnSignUp;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editId = (EditText) findViewById(R.id.username);
        editpsw = (EditText) findViewById(R.id.psw);

        btnSignin = (Button) findViewById(R.id.signin);

        btnSignin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String str = editId.getText().toString();
                String str1 = editpsw.getText().toString();
                //Toast.makeText(MainActivity.this,"Hello New user !!!" +str,Toast.LENGTH_LONG).show();
               // if (TextUtils.isEmpty(str) || TextUtils.isEmpty(str1)) {
                    //btnSignin.setTooltipText("Send an email");

               // } else {
                    if (str.equals("a@g.com") && str1.equals("12345")) {
                        Toast.makeText(MainActivity.this, "Hello New user !!!" + str, Toast.LENGTH_LONG).show();

                    } else {
                        Toast.makeText(MainActivity.this, "Sorry!!!", Toast.LENGTH_LONG).show();

                    }
                }

        });

        btnSignUp = (Button) findViewById(R.id.signup);

        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Student s1 = new Student();
                s1.setStudentId(100);
                s1.setStudentName("Vidhi");

                Employee e1 = new Employee();
                e1.setEmpId(100);
                e1.setEmpName("Vidhi Mehta");
                e1.setSalary(2000);
                e1.setGender(true);

                Intent i = new Intent(MainActivity.this, SignUpActivity.class);
                i.putExtra("name", "Charmi");
                i.putExtra("age", 4);
                i.putExtra("Student",s1);
                i.putExtra("Employee",e1);
                startActivity(i);


            }
        });

    }
}
