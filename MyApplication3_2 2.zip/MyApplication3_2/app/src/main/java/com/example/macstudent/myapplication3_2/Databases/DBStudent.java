package com.example.macstudent.myapplication3_2.Databases;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.example.macstudent.myapplication3_2.MainActivity;
import com.example.macstudent.myapplication3_2.Modal.Student;

/**
 * Created by macstudent on 2018-04-10.
 */
import java.lang.reflect.Array;
import java.util.ArrayList;

public class DBStudent {
    public static final String TABLE_STUDENT = "tblStudent";
    public static final String KEY_STUDENT_NAME = "stdName";
    public static final String KEY_STUDENT_ID = "stdId";
    public static final String KEY_STUDENT_GENDER = "stdGender";
    public static final String KEY_STUDENT_CITY = "stdCity";
    public static final String KEY_STUDENT_SCI = "stdSci";
    public static final String KEY_STUDENT_MATHS = "stdMaths";
    public static final String KEY_STUDENT_SST = "stdSst";
    public static final String KEY_STUDENT_ENGLISH = "stdEng";
    public static final String KEY_STUDENT_HINDI = "stdHindi";
    public static final String KEY_STUDENT_TOTAL = "stdTotal";
    public static final String KEY_STUDENT_PER = "stdPer";
    public static final String KEY_STUDENT_GRADE = "stdGrade";
    private static final String TAG = MainActivity.class.getName();
    Context context;
    private DBHelper dbHelper;

    public DBStudent(Context context) {
        this.context = context;
    }

    public void insertStudent(Student std) {
        dbHelper = new DBHelper(context);
        SQLiteDatabase database = dbHelper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(KEY_STUDENT_ID, std.getStudentId());
        cv.put(KEY_STUDENT_NAME, std.getStudentName());
        cv.put(KEY_STUDENT_GENDER, std.getGender());
        cv.put(KEY_STUDENT_MATHS, std.getMaths());
        cv.put(KEY_STUDENT_SCI, std.getSci());
        cv.put(KEY_STUDENT_ENGLISH, std.getEng());
        cv.put(KEY_STUDENT_HINDI, std.getHindi());
        cv.put(KEY_STUDENT_SST, std.getSst());
        cv.put(KEY_STUDENT_CITY, std.getCity());
        cv.put(KEY_STUDENT_TOTAL, 0);
        cv.put(KEY_STUDENT_PER , 0);
        cv.put(KEY_STUDENT_GRADE, 0);
        database.insert(TABLE_STUDENT, "null", cv);
        database.close();

    }

    public void updateStudent(Student std) {
        dbHelper = new DBHelper(context);
        SQLiteDatabase database = dbHelper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(KEY_STUDENT_ID, std.getStudentId());
        cv.put(KEY_STUDENT_NAME, std.getStudentName());
        cv.put(KEY_STUDENT_GENDER, std.getGender());
        cv.put(KEY_STUDENT_MATHS, std.getMaths());
        cv.put(KEY_STUDENT_SCI, std.getSci());
        cv.put(KEY_STUDENT_ENGLISH, std.getEng());
        cv.put(KEY_STUDENT_HINDI, std.getHindi());
        cv.put(KEY_STUDENT_SST, std.getSst());
        cv.put(KEY_STUDENT_CITY, std.getCity());

        database.update(TABLE_STUDENT, cv, KEY_STUDENT_ID + "=?", new String[]{String.valueOf(std.getStudentId())});
    }

    public void deleteStudent(Student std) {
        dbHelper = new DBHelper(context);
        SQLiteDatabase database = dbHelper.getWritableDatabase();
        database.delete(TABLE_STUDENT, KEY_STUDENT_ID + "=?", new String[]{String.valueOf(std.getStudentId())});
        database.close();


    }


    public ArrayList<Student> getAllStudent() {
        dbHelper = new DBHelper(context);
        SQLiteDatabase database = dbHelper.getWritableDatabase();

        Cursor cursor = database.query(TABLE_STUDENT,
                null,
                null,
                null,
                null,
                null,
                null);
        if (cursor != null) {
            if (cursor.getCount() > 0) {

                while (cursor.moveToNext()) {
                    Student std = new Student();
                    std.setStudentId(cursor.getInt(0));
                    std.setStudentName(cursor.getString(1));
                    std.setGender(cursor.getString(2));
                    std.setMaths(cursor.getString(3));
                    std.setSci(cursor.getString(4));
                    std.setEng(cursor.getString(5));
                    std.setHindi(cursor.getString(6));
                    std.setSst(cursor.getString(7));
                    std.setCity(cursor.getString(8));
                    std.setTotal(cursor.getString(9));
                    std.setPer(cursor.getString(10));
                    std.setGrade(cursor.getString(11));

                    Log.d(TAG, std.toString());

                  //  Log.d("Student", std.getStudentId() + " : " + std.getStudentName() + std.getGender() + std.getMaths() + std.getSci()+ std.getEng()  +  std.getHindi()  + std.getSst() + std.getCity() + std.getTotal() + std.getPer() + std.getGrade());
                }
            }

        }
        database.close();
        return null;
    }
}
