package com.example.macstudent.myapplication3_2.Modal;

/**
 * Created by macstudent on 2018-04-06.
 */

public class Student {

    private int studentId;
    private String studentName;
    private String gender;
    private String city;
    private String sst;
    private String maths;
    private String sci;
    private String hindi;
    private String eng;
    private String total;
    private String per;
    private String grade;
    private String subject [] ;

    public String getSst() {
        return sst;
    }

    public void setSst(String sst) {
        this.sst = sst;
    }

    public String getMaths() {
        return maths;
    }

    public void setMaths(String maths) {
        this.maths = maths;
    }

    public String getSci() {
        return sci;
    }

    public void setSci(String sci) {
        this.sci = sci;
    }

    public String getHindi() {
        return hindi;
    }

    public void setHindi(String hindi) {
        this.hindi = hindi;
    }

    public String getEng() {
        return eng;
    }

    public void setEng(String eng) {
        this.eng = eng;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public String getPer() {
        return per;
    }

    public void setPer(String per) {
        this.per = per;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }



    public Student(int studentId, String studentName, String gender, String city) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.gender = gender;
        this.city = city;

    }
    public Student()
    {

    }

    public void calMrks()
    {

        total = maths.toString() + sst.toString() + sci.toString() + hindi.toString() + eng.toString() ;
    }
    @Override
    public String toString() {
        return "Student{" +
                "studentId=" + studentId +
                ", studentName='" + studentName + '\'' +
                ", gender='" + gender + '\'' +
                ", city='" + city + '\'' +
                ", sst='" + sst + '\'' +
                ", maths='" + maths + '\'' +
                ", sci='" + sci + '\'' +
                ", hindi='" + hindi + '\'' +
                ", eng='" + eng + '\'' +
                ", total='" + total + '\'' +
                ", per='" + per + '\'' +
                ", grade='" + grade + '\'' +
                '}';
    }
}
