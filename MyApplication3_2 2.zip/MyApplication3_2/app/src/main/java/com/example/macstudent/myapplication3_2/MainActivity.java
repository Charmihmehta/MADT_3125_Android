package com.example.macstudent.myapplication3_2;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;

import com.example.macstudent.myapplication3_2.Databases.DBStudent;
import com.example.macstudent.myapplication3_2.Modal.Student;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class MainActivity extends Activity {


    @BindView(R.id.stdId)
    EditText stdId;
    @BindView(R.id.stdName)
    EditText stdName;
    @BindView(R.id.male)
    RadioButton male;
    @BindView(R.id.female)
    RadioButton female;
    @BindView(R.id.radiogroup)
    RadioGroup radiogroup;
    @BindView(R.id.maths)
    EditText maths;
    @BindView(R.id.sci)
    EditText sci;
    @BindView(R.id.eng)
    EditText eng;
    @BindView(R.id.hindi)
    EditText hindi;
    @BindView(R.id.sst)
    EditText sst;
    @BindView(R.id.city)
    Spinner city;
    @BindView(R.id.submit)
    Button submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ButterKnife.bind(this);


    }


    public void radioValue() {


    }

    public String mrks()
    {
      String total = maths.getText().toString() + sci.getText().toString() + eng.getText().toString() + hindi.getText().toString() + sst.getText().toString();
       return  total;

    }

    @OnClick(R.id.submit)
    public void onViewClicked() {
        Student std = new Student();
        std.setStudentId(Integer.parseInt(stdId.getText().toString()));
        std.setStudentName(stdName.getText().toString());

        std.setMaths(maths.getText().toString());
        std.setSci(sci.getText().toString());
        std.setEng(eng.getText().toString());
        std.setHindi(hindi.getText().toString());
        std.setSst(sst.getText().toString());
        std.setCity((String) city.getItemAtPosition(city.getSelectedItemPosition()));
        mrks();
        std.setPer(stdName.getText().toString());
        std.setGrade(stdName.getText().toString());


        DBStudent db = new DBStudent(MainActivity.this);
        db.insertStudent(std);
        db.getAllStudent();

    }
}


