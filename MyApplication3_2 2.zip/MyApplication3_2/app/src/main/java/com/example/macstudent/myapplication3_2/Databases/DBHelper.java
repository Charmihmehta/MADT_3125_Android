package com.example.macstudent.myapplication3_2.Databases;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by macstudent on 2018-04-10.
 */

public class DBHelper extends SQLiteOpenHelper
{
    private static final String DB_NAME = "dbStudent";
    private static final  int DB_VERSION = 1;

    public DBHelper(Context context)
    {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String studentTable = "CREATE TABLE " + DBStudent.TABLE_STUDENT
                + "(" + DBStudent.KEY_STUDENT_ID + " TEXT PRIMARY KEY, "
                + DBStudent.KEY_STUDENT_NAME + " TEXT , "
                + DBStudent.KEY_STUDENT_GENDER + " TEXT , "
                + DBStudent.KEY_STUDENT_MATHS + " TEXT , "
                + DBStudent.KEY_STUDENT_SCI + " TEXT , "
                + DBStudent.KEY_STUDENT_ENGLISH + " TEXT , "
                + DBStudent.KEY_STUDENT_HINDI + " TEXT , "
                + DBStudent.KEY_STUDENT_SST + " TEXT , "
                + DBStudent.KEY_STUDENT_CITY + " TEXT , "
                + DBStudent.KEY_STUDENT_TOTAL + " TEXT , "
                + DBStudent.KEY_STUDENT_PER + " TEXT , "
                + DBStudent.KEY_STUDENT_GRADE + " TEXT )";
        db.execSQL(studentTable);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("drop table " + DBStudent.TABLE_STUDENT);
        onCreate(db);

    }
}
