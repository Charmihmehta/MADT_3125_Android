package com.example.manpreetkaur.box;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.BitmapDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.view.animation.TranslateAnimation;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Paint paint = new Paint();
        paint.setColor(Color.parseColor("#da4747"));
        Bitmap bg = Bitmap.createBitmap(480,800,Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bg);
        canvas.drawRect(50,50,200,200,paint);
        LinearLayout li = (LinearLayout) findViewById(R.id.rec);
        li.setBackground(new BitmapDrawable(bg));

        LinearLayout animation1 = (LinearLayout) findViewById(R.id.rec);


        Random r = new Random();
        int no = 3;
        switch (r.nextInt(no))
        {
            case 0: horizontal(animation1);
            break;

            case 1: vertical(animation1);
            break;

            case 2: slide(animation1);
            break;
            default:vertical(animation1);
        }
       // horizontal(animation1);
       //vertical(animation1);
   // slide(animation1);

    }

    protected void vertical(LinearLayout animation1)
    {
        TranslateAnimation animation = new TranslateAnimation(0.0f, 00.0f,
                0.0f, 1000.0f);
        animation.setDuration(5000);
        animation.setRepeatCount(5);
        animation.setRepeatMode(2);
        animation.setFillAfter(true);
        animation1.startAnimation(animation);

    }
    protected void horizontal(LinearLayout animation1)
    {
        TranslateAnimation animation = new TranslateAnimation(0.0f, 400.0f,
                0.0f, 0.0f);
        animation.setDuration(5000);
        animation.setRepeatCount(5);
        animation.setRepeatMode(2);
        animation.setFillAfter(true);
        animation1.startAnimation(animation);

    }
    protected void slide(LinearLayout animation1)
    {
        TranslateAnimation animation = new TranslateAnimation(0.0f, 500.0f,
                0.0f, 1000.0f);
        animation.setDuration(5000);
        animation.setRepeatCount(5);
        animation.setRepeatMode(2);
        animation.setFillAfter(true);
        animation1.startAnimation(animation);

    }
}
