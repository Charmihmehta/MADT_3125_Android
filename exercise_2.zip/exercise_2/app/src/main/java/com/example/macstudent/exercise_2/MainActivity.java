package com.example.macstudent.exercise_2;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.BitmapDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.AbsoluteLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.util.DisplayMetrics;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Timer timer = new Timer();
        MyTimer mt = new MyTimer();

        timer.schedule(mt, 500, 500);
        //canvas.drawRect(50,50,200,200,paint);


//        RelativeLayout.LayoutParams absParams = (RelativeLayout.LayoutParams) li.getLayoutParams();
//        DisplayMetrics displaymetrics = new DisplayMetrics();
//        getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
//        int width = displaymetrics.widthPixels;
//        int height = displaymetrics.heightPixels;


//        absParams. =  r.nextInt(width ) ;
////        absParams.height =  r.nextInt(height );
////        li.setLayoutParams(absParams);

        //absParams.setMargins();

    }

    class MyTimer extends TimerTask {

        public void run() {

            //This runs in a background thread.
            //We cannot call the UI from this thread, so we must call the main UI thread and pass a runnable
            runOnUiThread(new Runnable() {

                public void run() {
                    LinearLayout li = (LinearLayout) findViewById(R.id.rec);
                    Random r = new Random();
                    int color = Color.argb(255, r.nextInt(256), r.nextInt(256), r.nextInt(256));
                    Paint paint = new Paint();
                    paint.setColor(color);
                    Bitmap bg = Bitmap.createBitmap(480, 800, Bitmap.Config.ARGB_8888);
                    Canvas canvas = new Canvas(bg);
                    li.setBackground(new BitmapDrawable(bg));

                    int a = 400;
                    int x = r.nextInt(a);
                    int y = r.nextInt(a);
                    int z = r.nextInt(a);
                    int w = r.nextInt(a);
                    canvas.drawRect(x, x, y, y, paint);
                }
            });
        }

    }
}