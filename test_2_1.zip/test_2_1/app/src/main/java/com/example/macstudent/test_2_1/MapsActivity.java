package com.example.macstudent.test_2_1;

import android.graphics.Color;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polygon;
import com.google.android.gms.maps.model.PolygonOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import java.text.DecimalFormat;
import java.util.List;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    public double CalculationByDistance(List<LatLng>latLngs) {
        int Radius = 6371;// radius of earth in Km

        double lat1 = latLngs.get(0).latitude;
        double lat2 =latLngs.get(1).latitude;
        double lon1 = latLngs.get(0).longitude;
        double lon2 = latLngs.get(1).longitude;
        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                + Math.cos(Math.toRadians(lat1))
                * Math.cos(Math.toRadians(lat2)) * Math.sin(dLon / 2)
                * Math.sin(dLon / 2);
        double c = 2 * Math.asin(Math.sqrt(a));
        double result = Radius * c;

        String s = String.format("%.2f", result);

        return Double.parseDouble(s);


    }

    public double CalculationByDistance1(List<LatLng>latLngs) {
        int Radius = 6371;// radius of earth in Km

        double lat1 = latLngs.get(0).latitude;
        double lat2 =latLngs.get(1).latitude;
        double lat3 = latLngs.get(2).latitude;
        double lat4 =latLngs.get(3).latitude;
        double lon1 = latLngs.get(0).longitude;
        double lon2 = latLngs.get(1).longitude;
        double lon3 = latLngs.get(2).longitude;
        double lon4 = latLngs.get(3).longitude;
        double dLat1 = Math.toRadians(lat2 - lat1);
        double dLon1 = Math.toRadians(lon2 - lon1);

        double dLat2 = Math.toRadians(lat3 - lat2);
        double dLon2 = Math.toRadians(lon3 - lon2);

        double dLat3 = Math.toRadians(lat4 - lat3);
        double dLon3 = Math.toRadians(lon4 - lon3);

        double dLat4 = Math.toRadians(lat1 - lat4);
        double dLon4 = Math.toRadians(lon1 - lon4);

        double a1 = Math.sin(dLat1 / 2) * Math.sin(dLat1 / 2)
                + Math.cos(Math.toRadians(lat1))
                * Math.cos(Math.toRadians(lat2)) * Math.sin(dLon1 / 2)
                * Math.sin(dLon1 / 2);
        double c1 = 2 * Math.asin(Math.sqrt(a1));

        double a2 = Math.sin(dLat2 / 2) * Math.sin(dLat2 / 2)
                + Math.cos(Math.toRadians(lat2))
                * Math.cos(Math.toRadians(lat3)) * Math.sin(dLon2 / 2)
                * Math.sin(dLon2 / 2);
        double c2 = 2 * Math.asin(Math.sqrt(a2));

        double a3 = Math.sin(dLat3 / 2) * Math.sin(dLat3 / 2)
                + Math.cos(Math.toRadians(lat3))
                * Math.cos(Math.toRadians(lat4)) * Math.sin(dLon3 / 2)
                * Math.sin(dLon3 / 2);
        double c3= 2 * Math.asin(Math.sqrt(a3));

        double a4 = Math.sin(dLat4 / 2) * Math.sin(dLat4 / 2)
                + Math.cos(Math.toRadians(lat4))
                * Math.cos(Math.toRadians(lat1)) * Math.sin(dLon4 / 2)
                * Math.sin(dLon4 / 2);
        double c4 = 2 * Math.asin(Math.sqrt(a4));
        double result = Radius * (c1+ c2+ c3 + c4);

        String s = String.format("%.2f", result);

        return Double.parseDouble(s);
    }
    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker in Sydney and move the camera
        LatLng manitoba = new LatLng(53.7609, - 98.8139);
        mMap.addMarker(new MarkerOptions().position(manitoba).title("Manitoba"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(manitoba));

        LatLng vancover = new LatLng(49.2827, -123.1207);
        mMap.addMarker(new MarkerOptions().position(vancover).title("Vancover"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(vancover));

        LatLng newyork = new LatLng(40.7128, -74.0060);
        mMap.addMarker(new MarkerOptions().position(newyork).title("New York"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(newyork));

        LatLng chicago = new LatLng(35.0078, -97.0929);
        mMap.addMarker(new MarkerOptions().position(chicago).title("Oklhoma"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(chicago));

        final Polyline line = mMap.addPolyline(new PolylineOptions()
                .add(manitoba,vancover)

                .width(5)
                .color(Color.RED)
                .clickable(true));

        final Polyline line1 = mMap.addPolyline(new PolylineOptions()

                .add(vancover,chicago)

                .width(5)
                .color(Color.RED)
                .clickable(true));

        final Polyline line2 = mMap.addPolyline(new PolylineOptions()

                .add(chicago,newyork)

                .width(5)
                .color(Color.RED)
                .clickable(true));

        final Polyline line3 = mMap.addPolyline(new PolylineOptions()

                .add(newyork,manitoba)
                .width(5)
                .color(Color.RED)
                .clickable(true));

        final Polygon polygon1 = googleMap.addPolygon(new PolygonOptions()
                .clickable(true)
                .add( manitoba,vancover,chicago,newyork)
                .fillColor(Color.GREEN)
        );



        mMap.setOnPolylineClickListener(new GoogleMap.OnPolylineClickListener() {
            @Override
            public void onPolylineClick(Polyline polyline) {
                Toast.makeText(MapsActivity.this, "Distance:" + CalculationByDistance(polyline.getPoints()) + "KM", Toast.LENGTH_SHORT).show();
            }
        });

        mMap.setOnPolygonClickListener(new GoogleMap.OnPolygonClickListener(){
           public void onPolygonClick(Polygon polygon){
               Toast.makeText(MapsActivity.this, "Total Distance :" + CalculationByDistance1(polygon1.getPoints()) + "KM", Toast.LENGTH_SHORT).show();
            }
        });


    }
}
