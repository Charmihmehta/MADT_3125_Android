package com.example.macstudent.myapplication2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {

    EditText editId;
    EditText editpsw;

    Button btnSignin;
    Button btnSignUp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editId = (EditText) findViewById(R.id.username);
        editpsw = (EditText) findViewById(R.id.psw);

        btnSignin = (Button) findViewById(R.id.signin);

        btnSignin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String str= editId.getText().toString();
                String str1 = editpsw.getText().toString();
                //Toast.makeText(MainActivity.this,"Hello New user !!!" +str,Toast.LENGTH_LONG).show();

                if(str.equals("a@g.com")  && str1.equals("12345"))
                {
                    Toast.makeText(MainActivity.this,"Hello New user !!!" +str,Toast.LENGTH_LONG).show();

                }
                else
                {
                    Toast.makeText(MainActivity.this,"Sorry!!!" ,Toast.LENGTH_LONG).show();

                }
            }
        });

        btnSignUp = (Button) findViewById(R.id.signup);

        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, SignUpActivity.class);
                startActivity(i);


            }
        });

    }
}
