package com.example.macstudent.myapplication3_2;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;

import butterknife.ButterKnife;
import butterknife.InjectView;
import butterknife.OnClick;

public class MainActivity extends Activity {

    @InjectView(R.id.stdId)
    EditText stdId;
    @InjectView(R.id.stdName)
    EditText stdName;
    @InjectView(R.id.male)
    RadioButton male;
    @InjectView(R.id.female)
    RadioButton female;
    @InjectView(R.id.maths)
    EditText maths;
    @InjectView(R.id.sci)
    EditText sci;
    @InjectView(R.id.eng)
    EditText eng;
    @InjectView(R.id.hindi)
    EditText hindi;
    @InjectView(R.id.sst)
    EditText sst;
    @InjectView(R.id.city)
    Spinner city;
    @InjectView(R.id.submit)
    Button submit;

  

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.inject(this);
    }

    @OnClick(R.id.submit)
    public void onViewClicked() {


    }
}
